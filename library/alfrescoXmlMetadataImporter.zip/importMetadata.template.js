<import resource="/Company Home/Data Dictionary/Scripts/xmlTransformer.js">

// Checks the document type and gets the associated XML content
var contentxml = getDocument(document);

// Checks if the XML content was found
if (!contentxml) {
    logger.log("XML file not found");
}

// Maps XML tags to document metadata properties
var xmlToProp = {
    "name": { prop: "name" },
    "title": { prop: "title" },
    "description": { prop: "description" },
    "author": { prop: "author" },
}

// Extracts and assigns XML tag values to metadata, if present
for (var tag in xmlToProp) {
    var conf = xmlToProp[tag];
    getXmlProp(contentxml, tag, conf.prop, conf.isDate);
}

// Saves the changes to the document
document.save();
