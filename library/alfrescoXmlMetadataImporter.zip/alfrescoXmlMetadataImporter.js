// Checks the document type and gets the associated XML content
function getDocument(document) {
    var nameXml = document.properties["name"].replace(".pdf", ".xml");
    // Looks for the XML file in the same folder as the PDF
    var fatherFiles = document.parent;
    var xmlFile = fatherFiles.childByNamePath(nameXml);
    return xmlFile.content.toString();
}

// Extracts the value of an XML tag by name, with optional date conversion
function getXmlValue(xmlString, tagName, isDate) {
    try {
        var startTag = "<" + tagName + ">";
        var endTag = "</" + tagName + ">";
        var startPos = xmlString.indexOf(startTag);

        if (startPos === -1) return null;
        startPos += startTag.length;
        var endPos = xmlString.indexOf(endTag, startPos);

        if (endPos === -1) return null;
        var value = xmlString.substring(startPos, endPos).trim();

        if (isDate) {
            return dateFormatterToAlfresco(value);
        }

        return value;
    } catch (e) {
        logger.log("Error parsing tag " + tagName + ": " + e);
        return null;
    }
}

// Converts date from YYYY/MM/DD to YYYY-MM-DDTHH:MM:SS.SSS-03:00
function dateFormatterToAlfresco(dateString) {
    try {
        var parts = dateString.split("/");
        if (parts.length === 3) {
            var formattedDate = parts[0] + "-" + parts[1].padStart(2, "0") + "-" + parts[2].padStart(2, "0") + "T00:00:00.111-03:00";
            return formattedDate;
        }
    } catch (e) {
        logger.log("Error transforming date: " + e);
        return null;
    }
}

// Assigns XML tag value to metadata property if it exists
function getXmlProp(xml, tag, prop, isDate) {
    var value = getXmlValue(xml, tag, isDate);
    if (value) document.properties[prop] = value;
}